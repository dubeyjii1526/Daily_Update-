# typed: strict
# frozen_string_literal: true

require "extend/os/mac/keg_only_reason" if OS.mac?
