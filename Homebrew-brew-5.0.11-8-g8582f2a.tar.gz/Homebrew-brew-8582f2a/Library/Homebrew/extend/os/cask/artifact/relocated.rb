# typed: strict
# frozen_string_literal: true

require "extend/os/linux/cask/artifact/relocated" if OS.linux?
