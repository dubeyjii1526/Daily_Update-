# typed: strict
# frozen_string_literal: true

require "extend/os/linux/cask/config" if OS.linux?
