# Documentation defined in Library/Homebrew/cmd/--taps.rb

# HOMEBREW_LIBRARY is set by brew.sh
# shellcheck disable=SC2154

homebrew---taps() {
  echo "${HOMEBREW_LIBRARY}/Taps"
}
